package proclient.module.combat;

import java.util.List;
import java.util.Random;

// Required Imports for Settings
import proclient.Dragon;
import proclient.settings.Setting;

import proclient.module.Category;
import proclient.module.Module;
import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MathHelper;

public class KillAura extends Module {

    // --- SETTINGS OBJECTS ---
    // We declare them here so we can access their values later
    public Setting attackRange;
    public Setting rotationRange;
    public Setting minCPS;
    public Setting maxCPS;
    public Setting autoBlock;

    // Internal variables
    private EntityLivingBase target;
    private long lastAttackTime = 0;
    private long nextAttackDelay = 0;
    private Random random = new Random();

    public KillAura() {
        super("KillAura", KeyboardConstants.KEY_NONE, Category.COMBAT);
        
        // --- REGISTER SETTINGS ---
        // This puts them into the SettingsManager so the ClickGUI can see them.
        // Arguments for Slider: Name, Parent, Default, Min, Max, isInteger
        // Arguments for Checkbox: Name, Parent, DefaultBoolean
        
        Dragon.setmgr.rSetting(attackRange = new Setting("Range", this, 3.1, 3.0, 6.0, false));
        Dragon.setmgr.rSetting(rotationRange = new Setting("Look Range", this, 6.0, 3.0, 8.0, false));
        Dragon.setmgr.rSetting(minCPS = new Setting("Min CPS", this, 9.0, 1.0, 20.0, false));
        Dragon.setmgr.rSetting(maxCPS = new Setting("Max CPS", this, 13.0, 1.0, 20.0, false));
        Dragon.setmgr.rSetting(autoBlock = new Setting("AutoBlock", this, true));
    }

    @Override
    public void onDisable() {
        super.onDisable();
        target = null;
        // Stop blocking if we turn the module off
        if(mc.thePlayer != null && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.gameSettings.keyBindUseItem.pressed = false;
        }
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled())
            return;

        // 1. Find the best target
        updateTarget();

        // 2. If we have a target...
        if (target != null) {
            
            // Rotate to face them
            faceEntity(target);

            // Check if they are close enough to actually hit using the Slider value
            if (mc.thePlayer.getDistanceToEntity(target) <= attackRange.getValDouble()) {
                attackTarget(target);
            } else {
                // If they are in look range but NOT attack range, unblock
                stopBlocking();
            }
        } else {
            // No target? Stop blocking.
            stopBlocking();
        }

        super.onUpdate();
    }

    private void updateTarget() {
        List<Entity> entities = mc.theWorld.loadedEntityList;
        // Use the rotation/look range slider value here
        double closestDist = rotationRange.getValDouble(); 
        target = null;

        for (Entity e : entities) {
            // Filter invalid targets
            if (!(e instanceof EntityLivingBase)) continue;
            if (e == mc.thePlayer) continue;
            if (!e.isEntityAlive()) continue;
            
            // Only target Players
            if (!(e instanceof EntityPlayer)) continue; 

            double dist = mc.thePlayer.getDistanceToEntity(e);

            if (dist <= closestDist) {
                closestDist = dist;
                target = (EntityLivingBase) e;
            }
        }
    }

    private void attackTarget(EntityLivingBase entity) {
        // Check timing (CPS)
        if (System.currentTimeMillis() - lastAttackTime >= nextAttackDelay) {
            
            // 1. Attack
            mc.thePlayer.swingItem();
            mc.playerController.attackEntity(mc.thePlayer, entity);

            // 2. Reset Timer
            lastAttackTime = System.currentTimeMillis();
            calculateNextDelay();

            // 3. AutoBlock (Visual + Packet) logic
            // Check if the AutoBlock checkbox is enabled
            if (autoBlock.isEnabled() && mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
                mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
            }
        }
    }

    private void stopBlocking() {
        // Helper to ensure we aren't holding block when we shouldn't be
        if (autoBlock.isEnabled() && mc.gameSettings.keyBindUseItem.isKeyDown()) {
            mc.gameSettings.keyBindUseItem.pressed = false; 
        }
    }

    private void calculateNextDelay() {
        // Get CPS from sliders
        double minVal = minCPS.getValDouble();
        double maxVal = maxCPS.getValDouble();

        // Safety check: Ensure min is not greater than max (if user messes up settings)
        double min = Math.max(1, minVal);
        double max = Math.max(min, maxVal);

        double randomCPS = min + (random.nextDouble() * (max - min));
        nextAttackDelay = (long) (1000.0 / randomCPS);
    }

    // --- Rotation Logic (Same as Aimbot for consistency) ---

    public synchronized void faceEntity(EntityLivingBase entity) {
        final float[] rotations = getRotationsNeeded(entity);
        if (rotations != null) {
            mc.thePlayer.rotationYaw = rotations[0];
            mc.thePlayer.rotationPitch = rotations[1] + 1.0F; 
        }
    }

    public static float[] getRotationsNeeded(Entity entity) {
        if (entity == null) return null;

        final double diffX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        final double diffZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY;

        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
        final float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
        
        return new float[] { 
            Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw), 
            Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch) 
        };
    }
}
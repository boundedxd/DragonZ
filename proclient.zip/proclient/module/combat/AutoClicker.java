package proclient.module.combat;

import java.util.Random;

// Required Imports
import proclient.Dragon;
import proclient.settings.Setting;

import proclient.module.Category;
import proclient.module.Module;
import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;

public class AutoClicker extends Module {

    // --- SETTINGS ---
    public Setting minCPS;
    public Setting maxCPS;
    public Setting clickOnHold; // "Triggerbot" style (only click when holding mouse)
    public Setting autoSprint;  // Optional: Force sprint on click

    // Internal variables for timing
    private long lastClickTime = 0;
    private long nextDelay = 0;
    private Random random = new Random();

    public AutoClicker() {
        super("AutoClicker", KeyboardConstants.KEY_NONE, Category.COMBAT);
        
        // --- REGISTER SETTINGS ---
        // Min CPS: Default 8, Range 1-20
        Dragon.setmgr.rSetting(minCPS = new Setting("Min CPS", this, 8.0, 1.0, 20.0, false));
        
        // Max CPS: Default 12, Range 1-20
        Dragon.setmgr.rSetting(maxCPS = new Setting("Max CPS", this, 12.0, 1.0, 20.0, false));
        
        // Click on Hold: Default true (standard behavior)
        Dragon.setmgr.rSetting(clickOnHold = new Setting("Click on Hold", this, true));
        
        // AutoSprint: Default false (So it doesn't break walking backwards by default)
        Dragon.setmgr.rSetting(autoSprint = new Setting("AutoSprint", this, false));
    }

    @Override
    public void onEnable() {
        super.onEnable();
        // Reset timing when enabled so it doesn't double-click instantly
        lastClickTime = System.currentTimeMillis();
        updateDelay();
    }

    @Override
    public void onUpdate() {
        if (!this.isToggled())
            return;

        // Logic for "Click On Hold" setting
        // If the setting is ON, and we are NOT holding the mouse, we stop here.
        if (clickOnHold.isEnabled() && !mc.gameSettings.keyBindAttack.isKeyDown()) {
            return;
        }

        // Check if enough time has passed for the next click
        if (System.currentTimeMillis() - lastClickTime >= nextDelay) {
            try {
                // Logic for "Auto Sprint" setting
                if(autoSprint.isEnabled()) {
                    mc.thePlayer.setSprinting(true);
                }
                
                // Perform the click
                mc.clickMouse();
                
                // Reset timer and calculate new random delay
                lastClickTime = System.currentTimeMillis();
                updateDelay();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Calculates the delay (in milliseconds) before the next click 
     * based on a random value between minCPS and maxCPS sliders.
     */
    private void updateDelay() {
        // Get values from Sliders
        double minVal = minCPS.getValDouble();
        double maxVal = maxCPS.getValDouble();

        // Prevent crashing if someone sets Min higher than Max
        double min = Math.max(1, minVal);
        double max = Math.max(min, maxVal);

        // Calculate random CPS
        double randomCPS = min + (random.nextDouble() * (max - min));
        
        // Convert CPS to Milliseconds (1000ms / CPS)
        nextDelay = (long) (1000.0 / randomCPS);
    }
}
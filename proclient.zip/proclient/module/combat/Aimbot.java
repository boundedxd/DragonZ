package proclient.module.combat;

import java.util.List;

// Required Imports
import proclient.Dragon;
import proclient.settings.Setting;

import proclient.module.Category;
import proclient.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

import net.lax1dude.eaglercraft.v1_8.internal.KeyboardConstants;

public class Aimbot extends Module {

    // --- SETTINGS ---
    public Setting range;
    public Setting speed;
    public Setting clickOnly; // If true, only aims when mouse is held down

    public Aimbot() {
        super("Aimbot", KeyboardConstants.KEY_NONE, Category.COMBAT);
        
        // --- REGISTER SETTINGS ---
        
        // Range: How far away to lock onto targets (Default 4.5 blocks)
        Dragon.setmgr.rSetting(range = new Setting("Range", this, 4.5, 3.0, 8.0, false));
        
        // Speed: How fast it rotates. 
        // Lower = Smoother/Legit (e.g., 10-20). Higher = Snappy (e.g., 90-180).
        Dragon.setmgr.rSetting(speed = new Setting("Speed", this, 20.0, 1.0, 180.0, false));
        
        // Click Only: Only aim when holding Left Click
        Dragon.setmgr.rSetting(clickOnly = new Setting("Click Only", this, false));
    }

    @Override
    public void onUpdate() {
        if (this.isToggled()) {
            // Check "Click Only" setting
            if(clickOnly.isEnabled() && !mc.gameSettings.keyBindAttack.isKeyDown()) {
                return;
            }
            
            this.aim();
        }
    }

    private void aim() {
        EntityPlayer target = getClosestPlayer();
        
        // Only aim if a target exists and is visible
        if (target != null && mc.thePlayer.canEntityBeSeen(target)) {
            faceEntity(target);
        }
    }

    // Better logic to find the closest player safely
    private EntityPlayer getClosestPlayer() {
        List<EntityPlayer> list = mc.theWorld.playerEntities;
        EntityPlayer closest = null;
        
        // Use the Slider value for range
        double lowestDist = range.getValDouble(); 

        for (EntityPlayer entity : list) {
            // Skip ourselves
            if (entity == mc.thePlayer) {
                continue;
            }
            
            // Skip dead or invisible players
            if(entity.isDead || entity.isInvisible()) {
                continue;
            }

            double dist = mc.thePlayer.getDistanceToEntity(entity);
            
            if (dist < lowestDist) {
                lowestDist = dist;
                closest = entity;
            }
        }
        return closest;
    }

    public synchronized void faceEntity(EntityLivingBase entity) {
        final float[] rotations = getRotationsNeeded(entity);

        if (rotations != null) {
            // Get current rotations
            float currentYaw = mc.thePlayer.rotationYaw;
            float currentPitch = mc.thePlayer.rotationPitch;

            // Get Speed from Slider
            float limit = (float) speed.getValDouble();

            // Smooth Yaw
            mc.thePlayer.rotationYaw = smoothRotation(currentYaw, rotations[0], limit);
            
            // Smooth Pitch (Using the same speed limit)
            mc.thePlayer.rotationPitch = smoothRotation(currentPitch, rotations[1] + 1.0F, limit);
        }
    }

    // This function handles the smoothing logic
    private float smoothRotation(float current, float target, float maxChange) {
        float change = MathHelper.wrapAngleTo180_float(target - current);
        
        if (change > maxChange) {
            change = maxChange;
        } else if (change < -maxChange) {
            change = -maxChange;
        }
        
        return current + change;
    }

    public static float[] getRotationsNeeded(Entity entity) {
        if (entity == null) {
            return null;
        }

        final double diffX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        final double diffZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY;

        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
            // Aim slightly lower than top of head (eyes)
            diffY = entityLivingBase.posY + entityLivingBase.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
        final float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
        
        return new float[] { yaw, pitch };
    }
}
package proclient.event;

public enum EventType {

    PRE,
    POST;
    
}

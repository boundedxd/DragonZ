package proclient.event.events;

import proclient.event.Event;

public class EventRenderNametag extends Event<EventRenderNametag> {
}

package proclient.event.events;

import proclient.event.Event;

public class EventSlowDown extends Event {
    
	private float slowDownMultiplier;

	public EventSlowDown(float slowDownMultiplier) {
		this.slowDownMultiplier = slowDownMultiplier;
	}

	public float getSlowDownMultiplier() {
		return slowDownMultiplier;
	}

	public void setSlowDownMultiplier(float slowDownMultiplier) {
		this.slowDownMultiplier = slowDownMultiplier;
	}

}

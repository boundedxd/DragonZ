(all of this is unconfirmed as i am currently unable to compile the client myself)
Fixed and improved : Aimbot, AutoClicker, Bhop, and Killaura
Added ClickGui implementation for their new settings.





P.S Make sure to delete / remove this file from the folder, not sure if it messes with it compiling.